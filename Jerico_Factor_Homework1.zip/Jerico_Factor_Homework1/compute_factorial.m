

function [b] = compute_factorial(n)
    if n == 0
        b = 1;
        return;
    else
        b = 1;
        for c = 1:n
            b = b * c;
        end 
        return; 
    end
end

